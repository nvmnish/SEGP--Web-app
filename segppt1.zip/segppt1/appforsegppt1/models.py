from django.db import models
from django.utils import timezone

class UserCredentials(models.Model):
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)

    def __str__(self):
        return self.username


class add_WSI_table(models.Model):
    slide_name = models.CharField(max_length=250)
    slide_number = models.CharField(max_length=250)
    magnification_level = models.CharField(max_length=250)
    zip_file = models.FileField(upload_to='addWSI_zipfiles/')
    uploaded_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.zip_file.name