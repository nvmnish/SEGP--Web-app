# forms.py

from django import forms
from .models import UserCredentials, add_WSI_table

class LoginForm(forms.ModelForm):
    class Meta:
        model = UserCredentials
        fields = ['username', 'password']


class add_WSI_Form(forms.ModelForm):
    class Meta:
        model = add_WSI_table
        fields = ['slide_name', 'slide_number', 'magnification_level', 'zip_file']
