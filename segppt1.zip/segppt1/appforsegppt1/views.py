from django.shortcuts import render,redirect
from django.contrib import messages
from .forms import LoginForm, add_WSI_Form
from .models import UserCredentials, add_WSI_table
from django.http import HttpResponseRedirect
from django.urls import reverse


#Testing if the admin page user authentication works by creating form.
def admin_page(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            # Check if the entered credentials match any record in the database
            if UserCredentials.objects.filter(username=username, password=password).exists():
                return redirect('options_page')  # Redirect to options_page
            else:
                messages.error(request, 'Invalid username or password.')
    else:
        form = LoginForm()
    return render(request, 'segppt1/admin_page.html', {'form': form}) 

def options_page(request):
    return render(request, 'segppt1/options_page.html')



def add_new_image_options(request):
    return render(request, 'segppt1/add_new_image_options.html')

def delete_image_options(request):
    return render(request, 'segppt1/delete_image_options.html')

def update_image_options(request):
    return render(request, 'segppt1/update_image_options.html')

def search_image_options(request):
    return render(request, 'segppt1/search_image_options.html')



def add_WSI(request):
    zip_file_instance = None
    if request.method == 'POST':
        form = add_WSI_Form(request.POST, request.FILES)
        if form.is_valid():
            zip_file_instance = form.save()
            return HttpResponseRedirect(reverse('success', kwargs={'zip_file_id': zip_file_instance.id}))
        else:
            print("Form is not valid")  # Add this print statement
            print(form.errors)
    else:
        form = add_WSI_Form()
    return render(request, 'segppt1/add_WSI.html', {'form': form})
    
def success(request, zip_file_id):
    zip_file_instance = add_WSI_table.objects.get(id=zip_file_id)
    return render(request, 'success.html', {'zip_file_instance': zip_file_instance})
        



def add_IHC(request):
    return render(request, 'segppt1/add_IHC.html')

def add_tumor_mask(request):
    return render(request, 'segppt1/add_tumor_mask.html')

def add_HandE(request):
    return render(request, 'segppt1/add_HandE.html')



def delete_WSI(request):
    return render(request, 'segppt1/delete_WSI.html')

def delete_IHC(request):
    return render(request, 'segppt1/delete_IHC.html')








