# SEGP--Web-app

This is where we'll build our main webpage
