import os
import ctypes
import tensorflow as tf
import numpy as np
from PIL import Image
from ctypes.util import find_library
import tempfile


dll_path = r'C:\openslide-x64\bin\libopenslide-0.dll'

if not os.path.exists(dll_path):
    raise FileNotFoundError(f"The specified 'libopenslide-0.dll' was not found in path: {dll_path}")

libopenslide = ctypes.cdll.LoadLibrary(dll_path)

# Ensure that the openslide bin directory is in the PATH
os.environ['PATH'] = r'C:\openslide-x64\bin;' + os.environ['PATH']

# Now, you should be able to import openslide without the DLL loading error.
from openslide import open_slide, __library_version__ as openslide_version

def process_slide(file_path, name, number):
    slide = open_slide(file_path)

    patch_size = 256
    level = 0

    slide_width, slide_height = slide.level_dimensions[level]

    num_patches_x = slide_width // patch_size
    num_patches_y = slide_height // patch_size

    patches_dir = f'media/patches/{name}_{number}'
    os.makedirs(patches_dir, exist_ok=True)

    for x in range(num_patches_x):
        for y in range(num_patches_y):
            start_x = x * patch_size
            start_y = y * patch_size

            patch = slide.read_region((start_x, start_y), level, (patch_size, patch_size))
            patch = patch.convert('RGB')

            patch_filename = os.path.join(patches_dir, f'patch_{x}_{y}.png')
            patch.save(patch_filename)

    print(f"Processed {num_patches_x * num_patches_y} patches for slide {name} with number {number}")

def handle_uploaded_file(f, name, number):
    with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
        for chunk in f.chunks():
            tmp_file.write(chunk)

    process_slide(tmp_file.name, name, number)

    # Remove the temporary file after processing
    os.remove(tmp_file.name)

def load_model(model_path):
    """Load the pre-trained model."""
    return tf.keras.models.load_model(model_path)

def predict_tumor(image_path, model_path):
    """Predict if an image contains a tumor."""
    model = load_model(model_path)

    # Load and preprocess the image
    img = Image.open(image_path)
    img = img.resize((256, 256))  # Assuming the model expects 256x256 images
    img_array = np.expand_dims(np.array(img), axis=0)  # Expand dims to match model's input shape

    # Predict
    prediction = model.predict(img_array)
    return prediction[0]