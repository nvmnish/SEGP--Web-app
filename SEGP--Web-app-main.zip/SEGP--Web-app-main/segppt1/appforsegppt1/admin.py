from django.contrib import admin
from .models import SlideImage

admin.site.register(SlideImage)
