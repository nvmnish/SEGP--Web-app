from django.db import models

class SlideImage(models.Model):
    title = models.CharField(max_length=255, help_text="A descriptive title for the slide.")
    image = models.ImageField(upload_to='slide_images/', null=True, help_text="The slide image file.")
    slide_number = models.CharField(max_length=50, blank=True, help_text="An optional identifier or number associated with the slide.")
    description = models.TextField(blank=True, help_text="A detailed description of the slide, including any relevant clinical or contextual information.")
    uploaded_at = models.DateTimeField(auto_now_add=True, help_text="The date and time the slide was uploaded.")

    def __str__(self):
        return f"{self.title} (Slide Number: {self.slide_number})"