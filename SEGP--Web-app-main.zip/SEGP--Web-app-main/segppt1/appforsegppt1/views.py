from django.shortcuts import render, redirect, HttpResponse, get_object_or_404
from django.http import HttpResponse
from django.core.files.images import ImageFile
from PIL import Image
from .utils import process_slide  # Make sure this is correctly imported from your utils module
import tempfile
import os
from .models import SlideImage
from .utils import predict_tumor
from .utils import handle_uploaded_file
from django.contrib import messages

# Create your views here.
def admin_page(request):
    return render(request, 'segppt1/admin_page.html')

def options_page(request):
    return render(request, 'segppt1/options_page.html')

def add_new_image_options(request):
    return render(request, 'segppt1/add_new_image_options.html')

def delete_image_options(request):
    return render(request, 'segppt1/delete_image_options.html')

def update_image_options(request):
    return render(request, 'segppt1/update_image_options.html')

def search_image_options(request):
    return render(request, 'segppt1/search_image_options.html')





def add_IHC(request):
    return render(request, 'segppt1/add_IHC.html')

def add_tumor_mask(request):
    return render(request, 'segppt1/add_tumor_mask.html')

def add_HandE(request):
    return render(request, 'segppt1/add_HandE.html')



def delete_WSI(request):
    return render(request, 'segppt1/delete_WSI.html')

def delete_IHC(request):
    return render(request, 'segppt1/delete_IHC.html')


def add_WSI(request):
    if request.method == 'POST':
        slide_file = request.FILES.get('fileUpload')
        slide_title = request.POST.get('slideTitle', 'default_title')
        slide_number = request.POST.get('slideNumber', '0')
        slide_description = request.POST.get('slideDescription', '')

        if slide_file:
            # Verify file extension (add or remove extensions as needed)
            if not slide_file.name.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp', '.svs')):
                messages.error(request, "Unsupported file type.")
                return redirect('add_WSI')  # Ensure 'add_WSI' matches the name in your URLs

            try:
                # Create a temporary file using mkstemp
                fd, tmp_file_path = tempfile.mkstemp(suffix=".tmp")
                try:
                    with os.fdopen(fd, 'wb') as tmp_file:
                        for chunk in slide_file.chunks():
                            tmp_file.write(chunk)

                    # Open and verify the image
                    with Image.open(tmp_file_path) as img:
                        img.verify()  # Verifies that the file is a valid image

                    # Process the slide and generate patches
                    process_slide(tmp_file_path, slide_title, slide_number)

                    # Create a new SlideImage instance and save it to the database
                    slide_image_instance = SlideImage.objects.create(
                        title=slide_title,
                        image=tmp_file_path,
                        slide_number=slide_number,
                        description=slide_description
                    )

                    # Redirect to the prediction view
                    return redirect('predict_tumor', slide_id=slide_image_instance.id)

                finally:
                    # Clean up the temporary file
                    os.remove(tmp_file_path)

            except Exception as e:
                messages.error(request, f"Error processing file: {e}")

            return redirect('add_WSI')

    return render(request, 'segppt1/add_WSI.html')

def predict_tumor_view(request, slide_id):
    slide_image = get_object_or_404(SlideImage, pk=slide_id)
    prediction_result = None  # Initialize prediction_result variable

    if request.method == 'POST':
        model_path = 'path/to/your/trained/model.h5'  # Make sure this path is correct
        try:
            prediction = predict_tumor(slide_image.image_field.path, model_path)
            # Process the prediction result as needed
            prediction_result = f"Prediction Result: {prediction[0]}"  # Customize as per your model's output
        except Exception as e:
            messages.error(request, f"Prediction error: {e}")

    # Include prediction_result in the context
    context = {
        'slide_image': slide_image,
        'prediction_result': prediction_result,
    }

    return render(request, 'segppt1/predict_tumor.html', context)
