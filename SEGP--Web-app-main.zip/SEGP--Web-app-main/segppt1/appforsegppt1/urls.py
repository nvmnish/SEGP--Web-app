from django.urls import path
from . import views

urlpatterns = [
    path('add_WSI/', views.add_WSI, name='add_WSI'),
    path('predict_tumor/<int:slide_id>/', views.predict_tumor_view, name='predict_tumor'),
    # Add other paths for new views
]
