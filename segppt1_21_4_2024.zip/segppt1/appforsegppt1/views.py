import os
import shutil
import tempfile
from django.shortcuts import render,redirect,get_object_or_404
from django.contrib import messages
from .forms import LoginForm, add_WSI_Form, add_IHC_Form, add_HandE_Form, add_tumorMask_Form
from .models import UserCredentials, add_WSI_table, add_IHC_table, add_HandE_table, add_tumorMask_table
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.conf import settings
import random
import string

folder_name_WSI ="WSI_zipfiles"
folder_name_IHC ="IHC_files"
folder_name_HandE ="HandE_files"
folder_name_tumorMask = "tumorMask_files"



def admin_page(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            # Check if the entered credentials match any record in the database
            if UserCredentials.objects.filter(username=username, password=password).exists():
                return redirect('options_page')  # Redirect to options_page
            else:
                messages.error(request, 'Invalid username or password.')
    else:
        form = LoginForm()
    return render(request, 'segppt1/admin_page.html', {'form': form}) 

def options_page(request):
    return render(request, 'segppt1/options_page.html')



def WSI(request):
    return render(request, 'segppt1/WSI.html')

def HandE(request):
    return render(request, 'segppt1/HandE.html')

def IHC(request):
    return render(request, 'segppt1/IHC.html')

def tumorMask(request):
    return render(request, 'segppt1/tumorMask.html')


#add, delete, search for WSI

#adding WSI:

def add_WSI(request):
    zip_file_instance = None
    if request.method == 'POST':
        form = add_WSI_Form(request.POST, request.FILES)
        if form.is_valid():
            zip_file_instance = form.save(commit=False)
            unique_code = generate_unique_code()  # Generate unique code
            zip_file_instance.unique_code = unique_code

            # Save the file to the 'media/' directory
            file_name = form.cleaned_data['zip_file'].name
            upload_path = os.path.join(settings.MEDIA_ROOT, folder_name_WSI , file_name)

            os.makedirs(os.path.dirname(upload_path), exist_ok=True)
            with open(upload_path, 'wb+') as destination:
                for chunk in request.FILES['zip_file'].chunks():
                    destination.write(chunk)

            # Update the model instance with the file path
            zip_file_instance.zip_file = file_name
            zip_file_instance.save()

            return render(request, 'success.html', {'zip_file_instance': zip_file_instance, 'unique_code': unique_code})
    else:
        form = add_WSI_Form()
    return render(request, 'segppt1/add_WSI.html', {'form': form})

def generate_unique_code():
    prefix = "WSI_"
    suffix = ''.join(random.choices(string.ascii_letters + string.digits, k=10))  # Generate random combination
    return prefix + suffix

def success(request, unique_code):
    zip_file_instance = add_WSI_table.objects.get(unique_code=unique_code)
    return render(request, 'success.html', {'zip_file_instance': zip_file_instance, 'unique_code': unique_code})
    


#deleting WSI:

def delete_WSI(request):
  directory_path = os.path.join(settings.MEDIA_ROOT, folder_name_WSI)
  upload_dir = directory_path
  files = os.listdir(upload_dir)
  return render(request, 'segppt1/delete_WSI.html', {'files': files})

def delete_file(request):
    if request.method == 'POST':
        file_name = request.POST.get('file_name')
        file_path = os.path.join(settings.MEDIA_ROOT, folder_name_WSI, file_name)
        if os.path.exists(file_path):
            os.remove(file_path)
            message = f"{file_name} was deleted successfully."
            try:
                uploaded_file = add_WSI_table.objects.get(zip_file=file_name)
                uploaded_file.delete()
                message = f"{file_name} was deleted successfully."
            except add_WSI_table.DoesNotExist:
                message = "Database entry not found for the file."
        else:
            message = "File not found."
        return render(request, 'segppt1/delete_file.html', {'message': message})
    else:
        return render(request, 'segppt1/delete_file.html')
    
#searching WSI:

def search_WSI(request):
    query = request.GET.get('q')
    upload_code = request.GET.get('upload_code')
    files = add_WSI_table.objects.all()

    if query:
        files = files.filter(zip_file__icontains=query)
    if upload_code:
        files = files.filter(unique_code=upload_code)
        
    for file in files:
        print(file.zip_file.name)
        
    return render(request, 'segppt1/search_WSI.html', {'files': files, 'query': query, 'upload_code': upload_code})

def download_file(request, file_name):
    file_path = os.path.join(settings.MEDIA_ROOT, folder_name_WSI, file_name)
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            response = HttpResponse(file.read(), content_type='application/octet-stream')
            response['Content-Disposition'] = f'attachment; filename="{file_name}"'
            return response
    else:
        return HttpResponse("File not found", status=404)
    
#add, delete, search for IHC

#adding IHC:

def add_IHC(request):
    zip_file_instance = None
    if request.method == 'POST':
        form = add_IHC_Form(request.POST, request.FILES)
        if form.is_valid():
            zip_file_instance = form.save(commit=False)
            unique_code = generate_unique_code_IHC()  # Generate unique code
            zip_file_instance.unique_code = unique_code

            # Save the file to the 'media/' directory
            file_name = form.cleaned_data['zip_file'].name
            upload_path = os.path.join(settings.MEDIA_ROOT, folder_name_IHC , file_name)

            os.makedirs(os.path.dirname(upload_path), exist_ok=True)
            with open(upload_path, 'wb+') as destination:
                for chunk in request.FILES['zip_file'].chunks():
                    destination.write(chunk)

            # Update the model instance with the file path
            zip_file_instance.zip_file = file_name
            zip_file_instance.save()

            return render(request, 'success_IHC.html', {'zip_file_instance': zip_file_instance, 'unique_code': unique_code})
    else:
        form = add_IHC_Form()
    return render(request, 'segppt1/add_IHC.html', {'form': form})

def generate_unique_code_IHC():
    prefix = "IHC_"
    suffix = ''.join(random.choices(string.ascii_letters + string.digits, k=10))  # Generate random combination
    return prefix + suffix

def success_IHC(request, unique_code):
    zip_file_instance = add_IHC_table.objects.get(unique_code=unique_code)
    return render(request, 'success_IHC.html', {'zip_file_instance': zip_file_instance, 'unique_code': unique_code})
    
#deleting_IHC:

def delete_IHC(request):
  directory_path = os.path.join(settings.MEDIA_ROOT, folder_name_IHC)
  upload_dir = directory_path
  files = os.listdir(upload_dir)
  return render(request, 'segppt1/delete_IHC.html', {'files': files})

def delete_file_IHC(request):
    if request.method == 'POST':
        file_name = request.POST.get('file_name')
        file_path = os.path.join(settings.MEDIA_ROOT, folder_name_IHC, file_name)
        if os.path.exists(file_path):
            os.remove(file_path)
            message = f"{file_name} was deleted successfully."
            try:
                uploaded_file = add_IHC_table.objects.get(zip_file=file_name)
                uploaded_file.delete()
                message = f"{file_name} was deleted successfully."
            except add_IHC_table.DoesNotExist:
                message = "Database entry not found for the file."
        else:
            message = "File not found."
        return render(request, 'segppt1/delete_file_IHC.html', {'message': message})
    else:
        return render(request, 'segppt1/delete_file_IHC.html')
    
 #Searching IHC:
     
def search_IHC(request):
    query = request.GET.get('q')
    upload_code = request.GET.get('upload_code')
    files = add_IHC_table.objects.all()

    if query:
        files = files.filter(zip_file__icontains=query)
    if upload_code:
        files = files.filter(unique_code=upload_code)
        
    for file in files:
        print(file.zip_file.name)
        
    return render(request, 'segppt1/search_IHC.html', {'files': files, 'query': query, 'upload_code': upload_code})

def download_file_IHC(request, file_name):
    file_path = os.path.join(settings.MEDIA_ROOT, folder_name_IHC, file_name)
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            response = HttpResponse(file.read(), content_type='application/octet-stream')
            response['Content-Disposition'] = f'attachment; filename="{file_name}"'
            return response
    else:
        return HttpResponse("File not found", status=404)

#add, delete, search H&E

#Adding H&E:
    

def add_HandE(request):
    zip_file_instance = None
    if request.method == 'POST':
        form = add_HandE_Form(request.POST, request.FILES)
        if form.is_valid():
            zip_file_instance = form.save(commit=False)
            unique_code = generate_unique_code_HandE() # Generate unique code
            zip_file_instance.unique_code = unique_code

            # Save the file to the 'media/' directory
            file_name = form.cleaned_data['zip_file'].name
            upload_path = os.path.join(settings.MEDIA_ROOT, folder_name_HandE , file_name)

            os.makedirs(os.path.dirname(upload_path), exist_ok=True)
            with open(upload_path, 'wb+') as destination:
                for chunk in request.FILES['zip_file'].chunks():
                    destination.write(chunk)

            # Update the model instance with the file path
            zip_file_instance.zip_file = file_name
            zip_file_instance.save()

            return render(request, 'success_HandE.html', {'zip_file_instance': zip_file_instance, 'unique_code': unique_code})
    else:
        form = add_HandE_Form()
    return render(request, 'segppt1/add_HandE.html', {'form': form})

def generate_unique_code_HandE():
    prefix = "HandE_"
    suffix = ''.join(random.choices(string.ascii_letters + string.digits, k=10))  # Generate random combination
    return prefix + suffix

def success_HandE(request, unique_code):
    zip_file_instance = add_HandE_table.objects.get(unique_code=unique_code)
    return render(request, 'success_HandE.html', {'zip_file_instance': zip_file_instance, 'unique_code': unique_code})

#Deleting H&E:
    
def delete_HandE(request):
  directory_path = os.path.join(settings.MEDIA_ROOT, folder_name_HandE)
  upload_dir = directory_path
  files = os.listdir(upload_dir)
  return render(request, 'segppt1/delete_HandE.html', {'files': files})

def delete_file_HandE(request):
    if request.method == 'POST':
        file_name = request.POST.get('file_name')
        file_path = os.path.join(settings.MEDIA_ROOT, folder_name_HandE, file_name)
        if os.path.exists(file_path):
            os.remove(file_path)
            message = f"{file_name} was deleted successfully."
            try:
                uploaded_file = add_HandE_table.objects.get(zip_file=file_name)
                uploaded_file.delete()
                message = f"{file_name} was deleted successfully."
            except add_HandE_table.DoesNotExist:
                message = "Database entry not found for the file."
        else:
            message = "File not found."
        return render(request, 'segppt1/delete_file_HandE.html', {'message': message})
    else:
        return render(request, 'segppt1/delete_file_HandE.html')    
    
#Searching H&E:
    
def search_HandE(request):
    query = request.GET.get('q')
    upload_code = request.GET.get('upload_code')
    files = add_HandE_table.objects.all()

    if query:
        files = files.filter(zip_file__icontains=query)
    if upload_code:
        files = files.filter(unique_code=upload_code)
        
    for file in files:
        print(file.zip_file.name)
        
    return render(request, 'segppt1/search_HandE.html', {'files': files, 'query': query, 'upload_code': upload_code})

def download_file_HandE(request, file_name):
    file_path = os.path.join(settings.MEDIA_ROOT, folder_name_HandE, file_name)
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            response = HttpResponse(file.read(), content_type='application/octet-stream')
            response['Content-Disposition'] = f'attachment; filename="{file_name}"'
            return response
    else:
        return HttpResponse("File not found", status=404)
    
#add, delete, search Tumor Mask

#Adding tumor mask: 

def add_tumorMask(request):
    zip_file_instance = None
    if request.method == 'POST':
        form = add_tumorMask_Form(request.POST, request.FILES)
        if form.is_valid():
            zip_file_instance = form.save(commit=False)
            unique_code = generate_unique_code_tumorMask()  # Generate unique code
            zip_file_instance.unique_code = unique_code

            # Save the file to the 'media/' directory
            file_name = form.cleaned_data['zip_file'].name
            upload_path = os.path.join(settings.MEDIA_ROOT, folder_name_tumorMask , file_name)

            os.makedirs(os.path.dirname(upload_path), exist_ok=True)
            with open(upload_path, 'wb+') as destination:
                for chunk in request.FILES['zip_file'].chunks():
                    destination.write(chunk)

            # Update the model instance with the file path
            zip_file_instance.zip_file = file_name
            zip_file_instance.save()

            return render(request, 'success_tumorMask.html', {'zip_file_instance': zip_file_instance, 'unique_code': unique_code})
    else:
        form = add_tumorMask_Form()
    return render(request, 'segppt1/add_tumorMask.html', {'form': form})

def generate_unique_code_tumorMask():
    prefix = "tumorMask_"
    suffix = ''.join(random.choices(string.ascii_letters + string.digits, k=10))  # Generate random combination
    return prefix + suffix

def success_tumorMask(request, unique_code):
    zip_file_instance = add_tumorMask_table.objects.get(unique_code=unique_code)
    return render(request, 'success_tumorMask.html', {'zip_file_instance': zip_file_instance, 'unique_code': unique_code})

#Deleting tumor mask:
    
def delete_tumorMask(request):
  directory_path = os.path.join(settings.MEDIA_ROOT, folder_name_tumorMask)
  upload_dir = directory_path
  files = os.listdir(upload_dir)
  return render(request, 'segppt1/delete_tumorMask.html', {'files': files})

def delete_file_tumorMask(request):
    if request.method == 'POST':
        file_name = request.POST.get('file_name')
        file_path = os.path.join(settings.MEDIA_ROOT, folder_name_tumorMask, file_name)
        if os.path.exists(file_path):
            os.remove(file_path)
            message = f"{file_name} was deleted successfully."
            try:
                uploaded_file = add_tumorMask_table.objects.get(zip_file=file_name)
                uploaded_file.delete()
                message = f"{file_name} was deleted successfully."
            except add_tumorMask_table.DoesNotExist:
                message = "Database entry not found for the file."
        else:
            message = "File not found."
        return render(request, 'segppt1/delete_file_tumorMask.html', {'message': message})
    else:
        return render(request, 'segppt1/delete_file_tumorMask.html')
    
#searching tumor mask:
    
def search_tumorMask(request):
    query = request.GET.get('q')
    upload_code = request.GET.get('upload_code')
    files = add_tumorMask_table.objects.all()

    if query:
        files = files.filter(zip_file__icontains=query)
    if upload_code:
        files = files.filter(unique_code=upload_code)
        
    for file in files:
        print(file.zip_file.name)
        
    return render(request, 'segppt1/search_tumorMask.html', {'files': files, 'query': query, 'upload_code': upload_code})

def download_file_tumorMask(request, file_name):
    file_path = os.path.join(settings.MEDIA_ROOT, folder_name_tumorMask, file_name)
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            response = HttpResponse(file.read(), content_type='application/octet-stream')
            response['Content-Disposition'] = f'attachment; filename="{file_name}"'
            return response
    else:
        return HttpResponse("File not found", status=404)
    