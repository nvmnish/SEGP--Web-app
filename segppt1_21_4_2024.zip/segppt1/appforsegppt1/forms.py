# forms.py

from django import forms
from .models import UserCredentials, add_WSI_table, add_IHC_table, add_HandE_table, add_tumorMask_table

class LoginForm(forms.ModelForm):
    class Meta:
        model = UserCredentials
        fields = ['username', 'password']


class add_WSI_Form(forms.ModelForm):
    class Meta:
        model = add_WSI_table
        fields = ['slide_name', 'slide_number', 'magnification_level', 'zip_file']
        
        
class add_IHC_Form(forms.ModelForm):
    class Meta:
        model = add_IHC_table
        fields = ['image_name', 'stain_type_IHC', 'zip_file']

class add_HandE_Form(forms.ModelForm):
    class Meta:
        model = add_HandE_table
        fields = ['image_name',  'zip_file']
        
class add_tumorMask_Form(forms.ModelForm):
    class Meta:
        model = add_tumorMask_table
        fields = ['mask_name', 'corres_slide_name', 'corres_slide_number', 'zip_file']